package com.example.moneymanager;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class Main_Page extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecycleViewAdapter mRecycleViewAdapter;
    private DatabaseHelper mDatabaseHelper;
    private Button mAddTrasactionButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        mDatabaseHelper = new DatabaseHelper(this);

        mRecyclerView = findViewById(R.id.expense_list);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        Cursor cursor = mDatabaseHelper.getAllData();
        mRecycleViewAdapter = new RecycleViewAdapter(this,cursor);
        mRecyclerView.setAdapter(mRecycleViewAdapter);

        RecyclerView.ItemDecoration itemDecoration = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        mRecyclerView.addItemDecoration(itemDecoration);

        mAddTrasactionButton = findViewById(R.id.create_button);
        mAddTrasactionButton.setOnClickListener(v -> {
            Intent intent = new Intent(Main_Page.this, AddTransactionActivity.class);
            intent.putExtra("user_id", 111);
            startActivity(intent);
            overridePendingTransition(R.anim.add_transaction_in, R.anim.main_page_out);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Cursor cursor = mDatabaseHelper.getAllData();
        mRecycleViewAdapter.changeCursor(cursor);
    }
}


