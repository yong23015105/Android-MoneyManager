package com.example.moneymanager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Typeface;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;

import androidx.recyclerview.widget.RecyclerView;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.ViewHolder> {
    private Cursor mCursor;
    private Context mContext;

    public RecycleViewAdapter(Context context, Cursor cursor) {
        this.mContext = context;
        this.mCursor = cursor;
    }

    private void showDialog(String name, String type, double amount, String date, String State, String description,long id) {
        AlertDialog.Builder mbuilder = new AlertDialog.Builder(mContext);
        mbuilder.setTitle("Item Details")
                .setMessage("name: " + name + "\n" +
                            "type: " + type + "\n" +
                            "amount: " + amount + "\n" +
                            "date: " + date + "\n" +
                            "State: " + State + "\n" +
                            "description: " + description)
                .setPositiveButton("Edit Transaction", (dialog, which) -> {

                    showEditDialog(name, type, amount, date, description, id);
                })
                .setNegativeButton("Delete Transaction", (dialog, which) -> {
                    DatabaseHelper dbHelper = new DatabaseHelper(mContext);
                    dbHelper.deleteTransaction(id);
                    Toast.makeText(mContext, "Transaction Deleted Successfully", Toast.LENGTH_SHORT).show();


                    Cursor newCursor = dbHelper.getAllData();
                    changeCursor(newCursor);
                })
                .setNeutralButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                });

        AlertDialog dialog = mbuilder.create();
        dialog.show();
    }

    private void showEditDialog(String name, String type, double amount, String date, String description, long id) {
        AlertDialog.Builder builder = new AlertDialog.Builder(mContext);

        LinearLayout layout = new LinearLayout(mContext);
        layout.setOrientation(LinearLayout.VERTICAL);

        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                100
        );
        params.setMargins(16, 16, 16, 16);


        final EditText input1 = new EditText(mContext);
        input1.setHint("Enter transaction name");
        input1.setText(name);
        input1.setLayoutParams(params);
        input1.setPadding(16,16,16,16);

        final Spinner spinner = new Spinner(mContext);
        String[] spinnerItems = {"Income", "Expense"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(mContext, android.R.layout.simple_spinner_item, spinnerItems);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        int spinnerPosition = adapter.getPosition(type);
        spinner.setSelection(spinnerPosition);
        spinner.setLayoutParams(params);
        spinner.setPadding(16,16,16,16);

        final EditText input3 = new EditText(mContext);
        input3.setHint("Enter transaction amount");
        input3.setText(String.valueOf(amount));
        input3.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input3.setLayoutParams(params);
        input3.setPadding(16,16,16,16);

        final EditText input4 = new EditText(mContext);
        input4.setHint("Enter transaction date");
        input4.setText(date);
        input4.setFocusable(false);
        input4.setFocusableInTouchMode(false);
        input4.setLayoutParams(params);
        input4.setPadding(16,16,16,16);

        final Button dateButton = new Button(mContext);
        dateButton.setText("ChooseDate");
        dateButton.setLayoutParams(params);
        dateButton.setPadding(16,16,16,16);

        final EditText input5 = new EditText(mContext);
        input5.setHint("Enter transaction description");
        input5.setText(description);
        input5.setLayoutParams(params);
        input5.setPadding(16,16,16,16);

        layout.addView(input1);
        layout.addView(spinner);
        layout.addView(input3);
        layout.addView(input4);
        layout.addView(dateButton);
        layout.addView(input5);


        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (mContext instanceof Activity) {
                    calenderUI.showCalendar((Activity) mContext, input4);
                } else {
                    Toast.makeText(mContext, "Context is not an Activity", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setTitle("Item Details")
                .setView(layout)
                .setPositiveButton("Edit Transaction", (dialog, which) -> {
                    String nameInput = input1.getText().toString();
                    String typeInput = spinner.getSelectedItem().toString();
                    double amountInput = Double.parseDouble(input3.getText().toString());
                    String dateInput = input4.getText().toString();
                    String descriptionInput = input5.getText().toString();

                    DatabaseHelper dbHelper = new DatabaseHelper(mContext);

                    boolean isUpdated = dbHelper.updateTransaction(id, nameInput, typeInput, amountInput, dateInput, descriptionInput);

                    if (isUpdated) {
                        Toast.makeText(mContext, "Transaction updated successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(mContext, "Failed to update transaction", Toast.LENGTH_SHORT).show();
                    }

                    Cursor newCursor = dbHelper.getAllData();
                    changeCursor(newCursor);
                })
                .setNeutralButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                });

        AlertDialog dialog = builder.create();
        dialog.show();
    }


    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_holder, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        if (mCursor.moveToPosition(position)) {
            int idIndex = mCursor.getColumnIndex("ID");
            long id = idIndex != -1 ? mCursor.getLong(idIndex) : -1;
            holder.id = id;

            int nameIndex = mCursor.getColumnIndex("Name");
            int typeIndex = mCursor.getColumnIndex("Type");
            int amountIndex = mCursor.getColumnIndex("Amount");
            int dateIndex = mCursor.getColumnIndex("Date");
            int StateIndex = mCursor.getColumnIndex("State");
            int descriptionIndex = mCursor.getColumnIndex("Description");

            String name = nameIndex != -1 ? mCursor.getString(nameIndex) : "No Name";
            String type = typeIndex != -1 ? mCursor.getString(typeIndex) : "Unknown Type";
            double amount = amountIndex != -1 ? mCursor.getDouble(amountIndex) : 0.0;
            String date = dateIndex != -1 ? mCursor.getString(dateIndex) : "Unknown Date";
            String state = StateIndex != -1 ? mCursor.getString(StateIndex) : "Unknown State";
            String description = descriptionIndex != -1 ? mCursor.getString(descriptionIndex) : "No Description";

            String mNameWord = "Name: " + name;
            String mTypeWord = "Type: " + type;
            String mAmountWord = "Amount: RM " + String.valueOf(amount);
            String mDateWord = "Date: " + date;
            String mStateWord = "State: " + state;
            String mDescriptionWord = "Description: " + description;

            SpannableString mNameWordSpan = new SpannableString(mNameWord);
            SpannableString mTypeWordSpan = new SpannableString(mTypeWord);
            SpannableString mAmountWordSpan = new SpannableString(mAmountWord);
            SpannableString mDateWordSpan = new SpannableString(mDateWord);
            SpannableString mStateWordSpan = new SpannableString(mStateWord);
            SpannableString mDescriptionWordSpan = new SpannableString(mDescriptionWord);

            mNameWordSpan.setSpan(new StyleSpan(Typeface.BOLD), 0, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            mTypeWordSpan.setSpan(new StyleSpan(Typeface.BOLD), 0, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            mAmountWordSpan.setSpan(new StyleSpan(Typeface.BOLD_ITALIC), 0, 8, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            mDateWordSpan.setSpan(new StyleSpan(Typeface.BOLD), 0, 6, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            mStateWordSpan.setSpan(new StyleSpan(Typeface.BOLD), 0, 7, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            mDescriptionWordSpan.setSpan(new StyleSpan(Typeface.BOLD), 0, 13, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            holder.mNameTextView.setText(mNameWordSpan);
            holder.mTypeTextView.setText(mTypeWordSpan);
            holder.mAmountTextView.setText(mAmountWordSpan);
            holder.mDateTextView.setText(mDateWordSpan);
            holder.mStateTextView.setText(mStateWordSpan);
            holder.mDescriptionTextView.setText(mDescriptionWordSpan);

            holder.itemView.setOnClickListener(v -> {
                showDialog(name, type, amount, date, state, description, id);
            });
        }
    }

    @Override
    public int getItemCount() {
        return mCursor != null ? mCursor.getCount() : 0;
    }

    public void changeCursor(Cursor newCursor) {
        if (mCursor != null) {
            mCursor.close();
        }
        mCursor = newCursor;
        notifyDataSetChanged(); 
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView mNameTextView;
        TextView mTypeTextView;
        TextView mAmountTextView;
        TextView mDateTextView;
        TextView mStateTextView;
        TextView mDescriptionTextView;
        long id;

        public ViewHolder(View itemView) {
            super(itemView);
            mNameTextView = itemView.findViewById(R.id.nameTextView);
            mTypeTextView = itemView.findViewById(R.id.typeTextView);
            mAmountTextView = itemView.findViewById(R.id.amountTextView);
            mDateTextView = itemView.findViewById(R.id.dateTextView);
            mStateTextView = itemView.findViewById(R.id.StateTextView);
            mDescriptionTextView = itemView.findViewById(R.id.descriptionTextView);
        }
    }
}

