package com.example.moneymanager;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String Database_name = "moneyManagerDatabase.db";
    private static final int Database_version = 6;
    public static final String Table_name = "TransactionTable";


    public DatabaseHelper(Context context) {
        super(context, Database_name, null, Database_version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + Table_name + " (" +
                "ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "User_ID INTEGER, " +
                "Name TEXT NOT NULL, " +
                "Type TEXT NOT NULL, " +
                "Amount REAL NOT NULL, " +
                "Date TEXT NOT NULL, " +
                "State TEXT NOT NULL," +
                "Description TEXT, " +
                "FOREIGN KEY(User_ID) REFERENCES user_accounts(User_ID) ON DELETE CASCADE" +
                ")";
        db.execSQL(createTable);

        String createUserTable = "CREATE TABLE User_Accounts (" +
                "User_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "Username TEXT NOT NULL UNIQUE, " +
                "Email TEXT NOT NULL UNIQUE, " +
                "Password TEXT NOT NULL" +
                ")";
        db.execSQL(createUserTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS " + Table_name);
            db.execSQL("DROP TABLE IF EXISTS user_accounts");
            onCreate(db);
        }
    }

    @SuppressLint("Range")
    public Cursor getAllData() {
        SQLiteDatabase db = this.getReadableDatabase();
        Calendar calendar = Calendar.getInstance();
        long currentDateMillis = calendar.getTimeInMillis();

        Cursor cursor = db.rawQuery("SELECT * FROM " + Table_name, null);
        String currentDateStr = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date(currentDateMillis));

        try {
            if (cursor.moveToFirst()) {
                do {
                    String itemDateStr = cursor.getString(cursor.getColumnIndex("Date"));

                    Date itemDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(itemDateStr);
                    Date currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(currentDateStr);

                    String state;

                    if (itemDate.after(currentDate)) {
                        state = "Not Achieved";
                    } else {
                        state = "Achieved";
                    }

                    String updateQuery = "UPDATE " + Table_name + " SET State = ? WHERE ID = ?";
                    db.execSQL(updateQuery, new Object[]{state, cursor.getLong(cursor.getColumnIndex("ID"))});

                } while (cursor.moveToNext());
            }
        } catch (ParseException e) {
            e.printStackTrace();
        } finally {
            cursor.close();
        }
        return db.rawQuery("SELECT * FROM " + Table_name, null);
    }



    public boolean AddTransaction(int userId, String name, String type, double amount, String date, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("User_ID", userId);
        values.put("Name", name);
        values.put("Type", type);
        values.put("Amount", amount);
        values.put("Date", date);
        values.put("State", "Pending");
        values.put("Description", description);

        long result = db.insert(Table_name, null, values);
        db.close();
        Log.d("Database", "Insert result: " + result);
        return result != -1;
    }

    public void deleteTransaction(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(Table_name, "id = ?", new String[]{String.valueOf(id)});
        db.close();
    }

    public boolean updateTransaction(long id, String name, String type, double amount, String date, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("name", name);
        values.put("type", type);
        values.put("amount", amount);
        values.put("date", date);
        values.put("description", description);

        int result = db.update(Table_name, values, "id = ?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

}

/*
*/